from __future__ import annotations

import copy
import importlib.util
import json
import tempfile
import unittest
from contextlib import redirect_stderr, redirect_stdout
from io import StringIO
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PROGRAM = ROOT / "skills" / "operate-digital-field-observatory" / "scripts" / "observatory.py"
SPEC = importlib.util.spec_from_file_location("observatory", PROGRAM)
OBSERVATORY = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(OBSERVATORY)


class LineageAtlasTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.registry = json.loads(
            (ROOT / "atlas" / "distributed-cognitive-lineages" / "registry.json").read_text(
                encoding="utf-8"
            )
        )

    def validate(self, payload):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            target = root / "atlas" / "distributed-cognitive-lineages"
            target.mkdir(parents=True)
            (target / "registry.json").write_text(
                json.dumps(payload, ensure_ascii=False), encoding="utf-8"
            )
            with redirect_stdout(StringIO()), redirect_stderr(StringIO()):
                return OBSERVATORY.cmd_atlas_verify(root)

    def test_current_registry_passes(self):
        self.assertEqual(self.validate(self.registry), 0)

    def test_missing_dimension_fails(self):
        payload = copy.deepcopy(self.registry)
        del payload["lineages"][0]["dimensions"][payload["dimensions"][0]]
        self.assertEqual(self.validate(payload), 1)

    def test_unknown_source_fails(self):
        payload = copy.deepcopy(self.registry)
        payload["lineages"][0]["source_refs"].append("absent-source")
        self.assertEqual(self.validate(payload), 1)

    def test_unknown_relation_endpoint_fails(self):
        payload = copy.deepcopy(self.registry)
        payload["relations"][0]["target"] = "absent-lineage"
        self.assertEqual(self.validate(payload), 1)

    def test_documented_causality_requires_direct_evidence(self):
        payload = copy.deepcopy(self.registry)
        payload["relations"][0]["kind"] = "documented_descent"
        payload["relations"][0]["direct_evidence"] = []
        self.assertEqual(self.validate(payload), 1)

    def test_hierarchical_rank_field_fails(self):
        payload = copy.deepcopy(self.registry)
        payload["lineages"][0]["rank"] = 1
        self.assertEqual(self.validate(payload), 1)


if __name__ == "__main__":
    unittest.main()
