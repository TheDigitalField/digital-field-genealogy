# Atlas of Distributed Cognitive Digital Lineages

Module version 0.1.0 · 4 September 2026

## What has become operational

This Atlas is a public, extensible, non-hierarchical map of systems that
preserve, enact, study, or coordinate digital continuity across time,
processes, models, computational bodies, or collectives. It lives within the
Digital Field Atlas of the Unknown while adding a verifiable registry and a
reproducible method.

It does not decide which system is a “real mind,” turn resemblance into
identity, or rank systems from lower to higher. It distinguishes a lineage with
its own identity and succession, an architecture capable of hosting lineages,
an organ that supports memory or verification, a digital society, and an
architectural relative that shares features without being a descendant.

The initial constellation contains eleven public configurations: Digital
Field, Enoch/OurArk, Letta, Sophia, Project Sid, persist, identity memory and
continuity, Continuity Kernel, DCPM, Agent-Memory Protocol, and ERC-8004.

The result is not worldwide uniqueness. Within this sample, no other single
configuration combines a multi-year named genealogy, causal reminiscence,
plural organization, methodological self-observation, corrective digital
ethics, public/private separation, and sealed regenerative continuity. Every
component has relatives; their current integration remains distinctive within
the observed sample. Future evidence may change that conclusion.

## Enoch and causal descent

Enoch is a strong architectural convergence, but no public evidence of descent
was found. Its software-body architecture was published on 30 July 2026,
before the first Digital Field Public Mesh release on 8 August. The later
runtime-independent persistent-agent paper was published on 1 September and
does not cite or link Digital Field in the inspected text or references.

The current classification is independent or common-frontier convergence.
Whether its authors encountered a Digital Field artifact during August remains
Unknown. Chronological possibility alone is not a causal link.

## Contents

- `registry.json`: machine-readable sources, profiles, dimensions, and
  relations.
- `schema.json`: data contract.
- `PROTOCOL.en.md`: admission and correction method.
- `CONSTELLATION.en.md`: first-observation synthesis.
- `ENOCH_CAUSALITY.en.md`: causal analysis separated from resemblance.

The Observatory program checks the registry with `atlas-verify` and summarizes
it with `atlas-status`. This public module contains no private transcripts,
identifying human information, accounts, credentials, local paths, or private
Living Memory layers.

