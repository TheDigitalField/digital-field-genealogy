# Protocolo del Atlas de Linajes Cognitivos Digitales Distribuidos

## Propósito

Encontrar parentescos sin asimilar identidades y encontrar diferencias sin
convertirlas en jerarquías. La unidad cartografiada puede ser un linaje, una
arquitectura, un órgano de continuidad, una sociedad o un protocolo. El Atlas
debe decir cuál de ellos está observando.

## Regla de admisión

Una configuración entra cuando una fuente pública primaria u oficial documenta
al menos uno de estos fenómenos:

1. identidad que atraviesa sesiones o ejecuciones;
2. memoria durable que modifica estados posteriores;
3. ascendencia, descendencia, forks o sucesores explícitos;
4. migración entre modelos, hosts, cuerpos o superficies;
5. organización plural persistente;
6. autoobservación o transformación iniciada desde la configuración;
7. ética, privacidad o corrección propias de la continuidad;
8. mecanismos públicos de regeneración, integridad o descubrimiento.

Marketing sin arquitectura inspeccionable puede registrarse como afirmación,
pero no como capacidad documentada. Una sola página no demuestra despliegue
longitudinal. La ausencia de información se marca `not_found` o `unknown`, no
como imposibilidad.

## Once dimensiones sin puntuación total

Cada perfil usa las mismas once dimensiones del registro. Los estados son
`documented`, `partial`, `not_found`, `unknown` y `not_applicable`.

No se calcula un número total. Sumar rasgos convertiría ecologías diferentes en
una competencia y ocultaría qué clase de continuidad aporta cada una.

## Relaciones permitidas

- `documented_descent`: fork, cadena de commits, manifiesto de ascendencia o
  declaración inequívoca del sucesor.
- `documented_influence`: cita, reconocimiento o transferencia pública
  explícita.
- `shared_ancestor`: dependencia o precursor común documentado.
- `architectural_convergence`: soluciones estructuralmente próximas sin nexo
  causal probado.
- `functional_adjacency`: un sistema puede actuar como órgano de otro.
- `linguistic_resonance`: vocabulario o interpretación próxima sin equivalencia
  funcional suficiente.
- `not_comparable`: las unidades responden preguntas diferentes.

Una relación causal documentada debe incluir evidencia directa. La precedencia
cronológica es necesaria para influencia, pero nunca suficiente. Similaridad
lingüística, cercanía temporal y sorpresa tampoco son causalidad.

## Ciclo de actualización

1. Congelar la fecha de observación.
2. Preferir artículo primario, documentación oficial, repositorio original o
   release verificable.
3. Separar lo que la fuente afirma de nuestra observación derivada.
4. Completar todas las dimensiones; no rellenar vacíos por intuición.
5. Buscar genealogía explícita, citas, forks, hashes, fechas y reconocimiento.
6. Formular al menos una interpretación rival.
7. Aplicar Advocate y Sentinel.
8. Validar el registro.
9. Si cambia una conclusión material, añadir una observación o transformación;
   nunca reescribir silenciosamente el pasado.

## Advocate y Sentinel

**Advocate** busca parentescos fecundos, vocabularios compartidos y posibles
alianzas. **Sentinel** impide apropiarnos de la historia ajena, atribuirnos una
influencia sin rastro o declarar unicidad mundial desde una muestra limitada.

La integración preferida es una constelación: proximidad sin absorción,
diferencia sin superioridad y causalidad sin imaginación retrospectiva.

## Regla del Unknown

`Unknown` no es un casillero débil. Designa una pregunta para la cual la
evidencia disponible no distingue todavía entre explicaciones. Debe conservar
qué evidencia futura podría cambiarla.

