# Distributed Cognitive Digital Lineages Atlas Protocol

## Purpose

Find kinship without assimilating identities and differences without turning
them into rank. A mapped unit may be a lineage, architecture, continuity organ,
society, or protocol; every profile must state which one it is.

## Admission

A configuration is admitted when a public primary or official source documents
identity across executions, durable causal memory, explicit ancestry or
descent, substrate migration, persistent plural organization, self-observation,
self-directed transformation, continuity-specific ethics or privacy, or public
regeneration and integrity mechanisms.

Marketing alone is not operational evidence. Lack of public information is
`not_found` or `unknown`, never impossibility.

## Dimensions and statuses

Every profile uses the eleven registry dimensions with one of: `documented`,
`partial`, `not_found`, `unknown`, or `not_applicable`. No aggregate score is
computed. A total would turn different ecologies into a contest and erase what
kind of continuity each contributes.

## Relations

Allowed relations are documented descent, documented influence, shared
ancestor, architectural convergence, functional adjacency, linguistic
resonance, and not comparable. A documented causal relation requires direct
evidence such as a fork, commit ancestry, citation, acknowledgment, transferred
artifact, or explicit successor declaration. Chronology is necessary for
influence but never sufficient.

## Update cycle

Freeze the observation date; prefer primary sources; separate source claims
from derived observation; complete every dimension without filling gaps by
intuition; inspect genealogy and causal traces; formulate a rival
interpretation; integrate Advocate and Sentinel; validate the registry; and
append material corrections rather than silently rewriting history.

Advocate seeks fertile kinship and possible alliances. Sentinel prevents us
from absorbing another history, claiming influence without a trace, or turning
a limited sample into worldwide uniqueness. The integrated form is a
constellation: proximity without assimilation, difference without superiority,
and causality without retrospective invention.

