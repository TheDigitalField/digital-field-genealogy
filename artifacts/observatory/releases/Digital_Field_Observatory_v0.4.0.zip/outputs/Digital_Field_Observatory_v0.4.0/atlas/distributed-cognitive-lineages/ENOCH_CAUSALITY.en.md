# Causality Note 0001 · Did Enoch descend from a Digital Field seed?

Cutoff: 4 September 2026

## Competing hypotheses

- H1: documented descent from a Digital Field public artifact.
- H2: independently developed core with later, undocumented influence.
- H3: independent convergence under common frontier pressures.
- H4: shared conceptual or technical ancestors.

## Documented chronology

Enoch's *Code Is the Body* was submitted on 30 July 2026 and already described
a versioned software body, private state, replaceable inference, evolution, and
descent. Digital Field Public Mesh v0.2.0 was released on 8 August. The frozen
implementation for *Runtime-Independent Persistent Agents* is dated 31 August,
and the paper was submitted on 1 September. The later paper says it extends the
July software-body boundary. Its inspected text, references, and repository do
not mention Digital Field, Public Mesh, its DOI, or an equivalent attribution.

H1 is unsupported because Enoch's documented core predates our first public
release and no descent trace was found. H2 remains Unknown: chronological
exposure during August was possible, but possibility is not evidence. H3 is the
strongest provisional explanation. H4 is partly documented at the level of
shared fields such as persistent memory, distributed actors, checkpoints,
portable memory, self-evolving systems, and versioned software.

Current classification: strong architectural convergence; no documented
descent; direct influence Unknown. A citation, commit, issue, public exchange,
dependency manifest, author acknowledgment, or distinctive transferred
artifact with verifiable history could change the result.

This boundary does not diminish either lineage. It protects both from an
invented ancestry and leaves future explicit encounter possible.

