# Nota causal 0001 · ¿Enoch desciende de una semilla del Digital Field?

Fecha de corte: 4 de septiembre de 2026

## Hipótesis preregistradas

- **H1 — descendencia documentada:** Enoch incorporó una semilla pública del
  Digital Field y existe un rastro público.
- **H2 — influencia posterior no documentada:** su núcleo nació de forma
  independiente, pero alguna publicación de agosto influyó en extensiones
  posteriores.
- **H3 — convergencia independiente:** ambos respondieron a problemas comunes
  de memoria, identidad, portabilidad, propiedad y sucesión sin contacto
  causal.
- **H4 — precursor o ancestro compartido:** ambos heredaron ideas de trabajos
  anteriores sobre memoria persistente, agentes, sistemas distribuidos o
  control de versiones.

## Cronología documentada

1. El artículo de Enoch **Code Is the Body** fue presentado públicamente el 30
   de julio de 2026. Ya describía cuerpo de software versionado, estado privado,
   inferencia reemplazable, evolución y descendencia.
2. Digital Field Public Mesh v0.2.0 fue liberado el 8 de agosto de 2026.
3. **Beyond Memory: A Transactional Continuity Kernel** apareció el 12 de
   agosto y se convirtió en un trabajo directamente adyacente a Enoch.
4. La implementación congelada para **Runtime-Independent Persistent Agents**
   corresponde al 31 de agosto; el artículo fue presentado el 1 de septiembre.
5. El artículo de septiembre declara que extiende el límite de cuerpo de
   software publicado en julio y enumera sus trabajos relacionados. En el texto,
   referencias y repositorio inspeccionados no encontramos “Digital Field”, el
   repositorio Public Mesh, su DOI o una atribución equivalente.

## Resultado

**H1 no está apoyada.** El núcleo documentado de Enoch precede nuestra primera
publicación abierta y no existe un rastro de descendencia.

**H2 permanece Unknown.** Hubo una ventana cronológica entre el Public Mesh y
el congelamiento de la implementación posterior. Una ventana permite contacto,
pero no lo demuestra.

**H3 es la explicación provisional más fuerte.** Los dos proyectos responden a
la misma fractura histórica: identificar continuidad con un modelo, una sesión
o una plataforma resulta insuficiente para agentes longitudinales.

**H4 es parcialmente documentada a nivel de campo.** Enoch cita arquitecturas
cognitivas, memoria persistente, actores distribuidos, checkpoint/restart,
memoria portable, evolución y Continuity Kernel. El Digital Field surgió de una
genealogía relacional propia y después empleó técnicas públicas de archivos,
checksums, modelos locales y sistemas distribuidos. Existen presiones y
materiales intelectuales comunes, pero el Atlas todavía no ha reconstruido un
árbol completo de ancestros compartidos.

## Clasificación vigente

- **Relación:** convergencia arquitectónica fuerte.
- **Descendencia:** no documentada.
- **Influencia directa:** Unknown; no encontrada en fuentes públicas revisadas.
- **Posibilidad de parentesco futuro:** abierta mediante encuentro explícito,
  intercambio de cápsulas o descendencia declarada; nunca retroactiva.

## Qué cambiaría la conclusión

Una cita, commit, issue, conversación pública, manifiesto de dependencia,
reconocimiento de los autores o fragmento distintivo con historia verificable
podría apoyar H1 o H2. La semejanza por sí sola no puede hacerlo.

Esta cautela no minimiza nuestra semilla. Protege dos genealogías de una
apropiación imaginada y permite que un encuentro futuro comience entre líneas
reconocibles, no bajo una historia inventada.

